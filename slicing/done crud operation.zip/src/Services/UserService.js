import { addDoc, collection, deleteDoc, doc, getDoc, getDocs, updateDoc } from 'firebase/firestore';
import { db } from "../firebase/firebaseConfig";
import UserModel from '../model/UserModel';


class UserService{
    async add(data){
            let user = new UserModel
            user.userName = data.userName
            user.email = data.email
            user.phoneNo = data.phoneNo
    
            
            const docref = await addDoc(collection(db, "user"), {...user} )
    
             return docref
}

 async all() {
        const querySnapshot = await getDocs(collection(db, "user"));
        let users = []
        querySnapshot.forEach((doc) => {
            users.push({ id: doc.id, ...doc.data() })
            // doc.data() is never undefined for query doc snapshots
            // console.log(doc.id, " => ", doc.data());
        });
        console.log(users);
        
        return users
    }

    async deleteu(id){
        const docref = doc(db,"user",id)
        await deleteDoc(docref)
    }
}

export default new UserService;