import { BrowserRouter, Routes, Route } from "react-router-dom";
import Counter from "./Components/Pages/Counter";
import Form from "./Components/Pages/Form";
import Layout from "./Components/Customer/Layout/Layout";
import FormHook from "./Components/Pages/FormHook";
import About from "./Components/Pages/About";
import Home from "./Components/Pages/Home";


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
        <Route path="/" element = {<Home/>} />
        <Route path="/counter" element = {<Counter/>} />
        <Route path="/formhook" element = {<FormHook/>} />
        <Route path="/form" element = {<Form/>} />
        <Route path="/about" element = {<About/>} />
      </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;